function mostrarSeccion(id) {
    let secciones = document.querySelectorAll(".seccion");
    
    secciones.forEach(seccion => {
        seccion.style.display = "none";
    });

    document.getElementById(id).style.display = "block";
}

  let carrito = [];
  let cantidad = 0;

  function agregarAlCarrito(producto) {
    carrito.push(producto);
    cantidad++;
    document.getElementById("cantidad-carrito").textContent = cantidad;
    actualizarListaCarrito();
  }

  function mostrarCarrito() {
    document.getElementById("carrito-panel").style.display = "block";
  }

  function cerrarCarrito() {
    document.getElementById("carrito-panel").style.display = "none";
  }

  function actualizarListaCarrito() {
    const lista = document.getElementById("lista-carrito");
    lista.innerHTML = "";
    carrito.forEach((item, index) => {
      const li = document.createElement("li");
      li.textContent = `${index + 1}. ${item}`;
      lista.appendChild(li);
    });
  }





